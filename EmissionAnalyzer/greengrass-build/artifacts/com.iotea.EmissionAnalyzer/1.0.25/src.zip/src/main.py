import json
import sys
import time
import logging

from awsgreengrasspubsubsdk.pubsub_client import AwsGreengrassPubSubSdkClient
from awsgreengrasspubsubsdk.message_formatter import PubSubMessageFormatter

logging.basicConfig(level=logging.INFO)
log = logging.getLogger(__name__)

print("EmissionAnalyzer starting...", flush=True)

# ----------------------------------------------------------
# Parse Greengrass config passed via CLI (from recipe.json)
# ----------------------------------------------------------
config = json.loads(sys.argv[1]) if len(sys.argv) > 1 else {}

BASE_TOPIC = config.get("base-pubsub-topic", "com.iotea.EmissionAnalyzer")
MQTT_SUB_TOPICS = config.get("mqtt-subscribe-topics", [])

log.info(f"Base PubSub topic: {BASE_TOPIC}")
log.info(f"MQTT subscription topics: {MQTT_SUB_TOPICS}")

# Track maximum CO₂ values
MAX_CO2_STATE = {}


# ==========================================================
# HANDLER CLASS
# ==========================================================
class EmissionHandler:
    def __init__(self, client):
        self.client = client
        self.formatter = PubSubMessageFormatter()

    # This is the callback entry point the SDK invokes
    def on_message(self, protocol, topic, message_id, status, route, message):
        
        # NOTE: For external MQTT (like the vehicle sender), the message 
        # is often the raw payload dictionary, not a wrapped structure.
        # We assign the whole 'message' as the 'payload'.
        try:
            payload = message 
            log.info(f"Received message on {topic}: {payload}")

            # The keys are now correctly named thanks to your change in the sender code
            vehicle_id = str(payload.get("vehicle_id", "unknown"))
            co2_val = float(payload.get("vehicle_CO2", 0))

            if vehicle_id == "unknown":
                log.error("Missing vehicle_id. Skipping.")
                return

            # Max logic
            prev = MAX_CO2_STATE.get(vehicle_id, co2_val)
            if co2_val > prev:
                MAX_CO2_STATE[vehicle_id] = co2_val

                publish_topic = f"vehicle/results/{vehicle_id}/max_co2"

                result = {
                    "vehicle_id": vehicle_id,
                    "max_CO2": co2_val,
                    "timestamp": int(time.time())
                }

                self.client.publish_message("ipc_mqtt", result)
                
                log.info(f"Published NEW MAX CO2 for {vehicle_id}: {result}")
            else:
                log.debug(
                    f"CO2 {co2_val} <= existing max {prev} for vehicle {vehicle_id}"
                )

        except Exception as e:
            log.error(f"Error processing message: {e}", exc_info=True)


# ==========================================================
# CLIENT INITIALIZATION
# ==========================================================
default_handler = EmissionHandler(None)  # filled after client creation

client = AwsGreengrassPubSubSdkClient(
    BASE_TOPIC,
    default_handler.on_message
)

default_handler.client = client

# Register object that contains on_message routes
client.register_message_handler(default_handler)

# Activate IPC + MQTT Pub/Sub
client.activate_ipc_pubsub()
client.activate_mqtt_pubsub()

# ==========================================================
# SUBSCRIPTIONS
# ==========================================================
for t in MQTT_SUB_TOPICS:
    log.info(f"Subscribing to {t} via ipc_mqtt")
    client.subscribe_to_topic("ipc_mqtt", t)

log.info("All subscriptions active.")
log.info("Running main loop...")

# ==========================================================
# MAIN LOOP
# ==========================================================
try:
    while True:
        time.sleep(1)
except KeyboardInterrupt:
    log.info("Shutting down...")
